﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace senddatawebview
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            InitBrowser();

        }
        private async Task initizated()
        {
            await webView21.EnsureCoreWebView2Async(null);
        }
        public async void InitBrowser()
        {
            await initizated();
            webView21.CoreWebView2.Navigate("https://www.google.com/");

        }

        private void button1_Click(object sender, EventArgs e)
        {
            senddata();
        }
        public async void senddata()
        {
            await webView21.ExecuteScriptAsync("document.getElementsByClassName('gLFyf')[0].value='itcore5761 youtube'");
            await webView21.ExecuteScriptAsync("document.getElementsByClassName('gNO89b')[0].click()");
        }
    }
}
